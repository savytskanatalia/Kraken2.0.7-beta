kraken2
=======

The second version of the Kraken taxonomic sequence classification system

Please refer to the Operating Manual (in docs/MANUAL.html) for details on
how to use Kraken 2.
